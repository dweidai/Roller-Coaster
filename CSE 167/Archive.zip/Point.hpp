//
//  Point.hpp
//  CSE 167
//
//  Created by Dwei on 11/15/18.
//  Copyright © 2018 Dwei. All rights reserved.
//

#ifndef Point_hpp
#define Point_hpp

#include <stdio.h>
class Point{
public:
    float x, y, z;
    Point(float a, float b, float c);
    ~Point();
    
};
#endif /* Point_hpp */
