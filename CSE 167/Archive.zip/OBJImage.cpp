//
//  OBJImage.cpp
//  CSE 167
//
//  Created by Dwei on 10/30/18.
//  Copyright © 2018 Dwei. All rights reserved.
//

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
