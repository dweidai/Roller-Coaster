//
//  Point.cpp
//  CSE 167
//
//  Created by Dwei on 11/15/18.
//  Copyright © 2018 Dwei. All rights reserved.
//

#include "Point.hpp"
Point::Point(float a, float b, float c){
    x = a;
    y = b;
    z = c;
}
Point:: ~Point(){
    
}
